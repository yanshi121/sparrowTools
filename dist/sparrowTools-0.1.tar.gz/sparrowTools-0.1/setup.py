from setuptools import setup, find_packages

setup(
    name='sparrowTools',
    version='0.1',
    description='Python的工具箱',
    packages=find_packages(),
    python_requires='>=3.11',
    install_requires=[]
)